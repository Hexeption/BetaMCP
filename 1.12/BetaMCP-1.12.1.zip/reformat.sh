#!/bin/bash
./runtime/reformat.py "$@"
