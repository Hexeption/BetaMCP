#!/bin/bash
./runtime/startclient.py "$@"
