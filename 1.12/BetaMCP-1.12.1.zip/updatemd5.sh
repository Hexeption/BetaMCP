#!/bin/bash
./runtime/updatemd5.py "$@"
